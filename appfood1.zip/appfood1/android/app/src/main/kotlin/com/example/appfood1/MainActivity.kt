package com.example.appfood1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
