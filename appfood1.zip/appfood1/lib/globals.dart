class Globals {
  static String? phoneNumber;
}
