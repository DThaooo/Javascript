import 'package:flutter/material.dart';
import 'globals.dart';

class PhoneNumberScreen extends StatefulWidget {
  @override
  _PhoneNumberScreenState createState() => _PhoneNumberScreenState();
}

class _PhoneNumberScreenState extends State<PhoneNumberScreen> {
  TextEditingController phoneNumberController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Set initial value for phoneNumberController if phoneNumber is not null
    if (Globals.phoneNumber != null) {
      phoneNumberController.text = Globals.phoneNumber!;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Phone Number'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // Widget để người dùng nhập số điện thoại
            TextField(
              controller: phoneNumberController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: 'Phone Number',
                suffixIcon: IconButton(
                  onPressed: () {
                    setState(() {
                      Globals.phoneNumber = phoneNumberController.text;
                    });
                  },
                  icon: Icon(Icons.save),
                ),
              ),
            ),
            SizedBox(height: 20.0),
            // Widget hiển thị số điện thoại đã thêm
            Text(
              'Phone Number:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10.0),
            Text(
              Globals.phoneNumber ?? 'No phone number added',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
